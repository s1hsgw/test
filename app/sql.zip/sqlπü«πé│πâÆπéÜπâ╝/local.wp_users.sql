/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_users` VALUES
(1,"murabito0421","$P$BhWXNprV0vGc1K338ayMmUdTQafUup1","murabito0421","mizuha.terashima@gmail.com","","2018-05-06 06:01:10","",0,"murabito0421");
