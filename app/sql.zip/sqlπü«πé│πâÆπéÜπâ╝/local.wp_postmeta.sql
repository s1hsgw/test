/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_postmeta` VALUES
(1,2,"_wp_page_template","default"),
(2,1,"_edit_lock","1525603945:1"),
(3,1,"total_sidebar_layout","right_sidebar"),
(4,5,"_edit_lock","1525604149:1"),
(5,5,"_customize_restore_dismissed","1"),
(6,2,"_edit_lock","1525604252:1");
